package com.parham.ai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout box;
    TextView vocalName, musicName, status;
    public void onCreate(Bundle b){
        super.onCreate(b);
        box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40,50,40,30);
        TextView title=new TextView(this); title.setText("Parham AI Voice"); title.setTextSize(28); title.setTextColor(Color.rgb(70,45,150));
        box.addView(title);
        vocalName=label("ووکال خودت را انتخاب کن");
        Button vocal=button("انتخاب فایل وکال"); vocal.setOnClickListener(v->pick(10));
        box.addView(vocal); box.addView(vocalName);
        musicName=label("اینسترومنتال را انتخاب کن");
        Button music=button("انتخاب آهنگ / اینسترومنتال"); music.setOnClickListener(v->pick(11));
        box.addView(music); box.addView(musicName);
        Button send=button("شروع پردازش AI"); send.setOnClickListener(v->{
            status.setText("فایل‌ها آماده‌اند. اتصال به موتور AI در نسخه سرویس متصل انجام می‌شود.");
        }); box.addView(send);
        status=label("وضعیت: آماده"); box.addView(status);
        setContentView(box);
    }
    TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(16); t.setPadding(0,18,0,18); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); return b; }
    void pick(int code){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("audio/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,code);
    }
    protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d); if(c!=RESULT_OK||d==null)return;
        String n=d.getData().getLastPathSegment();
        if(r==10)vocalName.setText("ووکال انتخاب شد: "+n);
        if(r==11)musicName.setText("اینسترومنتال انتخاب شد: "+n);
    }
}
